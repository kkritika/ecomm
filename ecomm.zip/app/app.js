/**
 * Main module of the application.
 */
(function() {
  'use strict';
  console.log('hi')
  angular.module('app', [
    'ui.router',
    'underscore',
    'ngStorage'
  ]);

})();